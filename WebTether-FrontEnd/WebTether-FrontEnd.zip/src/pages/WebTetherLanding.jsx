"use client"

import { useState, useEffect } from "react"
import { useTheme } from "../contexts/ThemeContext"
import { useAuth } from "../contexts/AuthContext"
import { Button } from "../components/ui/button"
import { Card, CardContent } from "../components/ui/card"
import { Badge } from "../components/ui/badge"
import { LoginDialog } from "../components/auth/LoginDialog"
import { SignupDialog } from "../components/auth/SignupDialog"
import { ThemeToggle } from "../components/ui/theme-toggle"
import {
  Globe,
  Shield,
  ArrowRight,
  DollarSign,
  ChevronUp,
  Menu,
  X,
  Rocket,
  Zap,
  Network,
  Sparkles,
  CheckCircle,
  Target,
  Lightbulb,
  Activity,
  TrendingUp,
  Wifi,
  Server,
  Eye,
} from "lucide-react"

export default function WebTetherLanding() {
  const { theme } = useTheme()
  const { user } = useAuth()
  const [showLoginDialog, setShowLoginDialog] = useState(false)
  const [showSignupDialog, setShowSignupDialog] = useState(false)
  const [showValidatorSignup, setShowValidatorSignup] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)
  const [activePings, setActivePings] = useState([])
  const [globalStats, setGlobalStats] = useState({
    validators: 0,
    websites: 0,
    pings: 0,
  })

  useEffect(() => {
    const locations = [
      { id: 1, name: "New York", x: 25, y: 40, country: "USA" },
      { id: 2, name: "London", x: 50, y: 35, country: "UK" },
      { id: 3, name: "Tokyo", x: 85, y: 45, country: "Japan" },
      { id: 4, name: "Sydney", x: 90, y: 75, country: "Australia" },
      { id: 5, name: "São Paulo", x: 35, y: 70, country: "Brazil" },
      { id: 6, name: "Mumbai", x: 75, y: 55, country: "India" },
      { id: 7, name: "Lagos", x: 52, y: 60, country: "Nigeria" },
      { id: 8, name: "Berlin", x: 52, y: 32, country: "Germany" },
      { id: 9, name: "Singapore", x: 80, y: 58, country: "Singapore" },
      { id: 10, name: "Toronto", x: 22, y: 38, country: "Canada" },
      { id: 11, name: "Dubai", x: 65, y: 50, country: "UAE" },
      { id: 12, name: "Seoul", x: 87, y: 42, country: "South Korea" },
    ]

    const interval = setInterval(() => {
      const randomLocation = locations[Math.floor(Math.random() * locations.length)]
      const newPing = {
        ...randomLocation,
        id: Date.now(),
        timestamp: Date.now(),
        status: Math.random() > 0.1 ? "success" : "warning", // 90% success rate
      }

      setActivePings((prev) => [...prev.slice(-8), newPing])
    }, 800) // Faster ping rate for more activity

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const interval = setInterval(() => {
      setGlobalStats((prev) => ({
        validators: Math.min(prev.validators + Math.floor(Math.random() * 2) + 1, 156),
        websites: Math.min(prev.websites + Math.floor(Math.random() * 3) + 1, 892),
        pings: prev.pings + Math.floor(Math.random() * 30) + 15,
      }))
    }, 3000) // Slower updates for more realistic feel

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleGetStarted = () => {
    if (user) {
      window.location.href = "/dashboard"
    } else {
      setShowSignupDialog(true)
    }
  }

  const handleBecomeValidator = () => {
    if (user) {
      window.location.href = "/dashboard?view=settings"
    } else {
      setShowValidatorSignup(true)
      setShowSignupDialog(true)
    }
  }

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setMobileMenuOpen(false)
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-background/90 border-b border-primary/30 shadow-lg">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3 cursor-pointer group">
              <div className="w-10 h-10 bg-gradient-to-br from-primary via-accent to-primary rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-primary/40 transition-all duration-300 group-hover:scale-110">
                <Network className="w-5 h-5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                  WebTether
                </span>
                <span className="text-xs text-muted-foreground -mt-1">Global Monitoring Network</span>
              </div>
            </div>

            <nav className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => scrollToSection("vision")}
                className="text-muted-foreground hover:text-primary transition-colors font-medium"
              >
                Vision
              </button>
              <button
                onClick={() => scrollToSection("network")}
                className="text-muted-foreground hover:text-primary transition-colors font-medium"
              >
                Network
              </button>
              <button
                onClick={() => scrollToSection("features")}
                className="text-muted-foreground hover:text-primary transition-colors font-medium"
              >
                Features
              </button>
              <button
                onClick={() => scrollToSection("early-access")}
                className="text-muted-foreground hover:text-primary transition-colors font-medium"
              >
                Early Access
              </button>
            </nav>

            <div className="hidden md:flex items-center space-x-4">
              <ThemeToggle />
              {user ? (
                <Button
                  onClick={() => (window.location.href = "/dashboard")}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg hover:shadow-primary/30"
                >
                  Dashboard
                </Button>
              ) : (
                <div className="flex items-center space-x-3">
                  <Button
                    variant="ghost"
                    onClick={() => setShowLoginDialog(true)}
                    className="hover:bg-primary/10 hover:text-primary"
                  >
                    Sign In
                  </Button>
                  <Button
                    onClick={handleGetStarted}
                    className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg hover:shadow-primary/30 hover:scale-105 transition-all duration-300"
                  >
                    Join Beta
                  </Button>
                </div>
              )}
            </div>

            <div className="md:hidden flex items-center space-x-3">
              <ThemeToggle />
              <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <section className="relative py-20 sm:py-32 overflow-hidden bg-gradient-to-br from-background via-primary/10 to-accent/10">
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-40 h-40 bg-primary/30 rounded-full blur-3xl animate-pulse" />
          <div
            className="absolute top-40 right-20 w-32 h-32 bg-accent/25 rounded-full blur-2xl animate-pulse"
            style={{ animationDelay: "1s" }}
          />
          <div
            className="absolute bottom-20 left-1/4 w-28 h-28 bg-primary/20 rounded-full blur-xl animate-pulse"
            style={{ animationDelay: "2s" }}
          />
          <div
            className="absolute top-1/2 right-1/3 w-24 h-24 bg-accent/15 rounded-full blur-2xl animate-pulse"
            style={{ animationDelay: "3s" }}
          />
        </div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-6xl mx-auto">
            <div className="space-y-8">
              <Badge className="backdrop-blur-sm bg-primary/15 border-primary/40 text-primary px-6 py-3 text-sm font-medium hover:bg-primary/20 transition-all duration-300">
                <Rocket className="w-4 h-4 mr-2" />
                Revolutionary Technology • Join the Future
              </Badge>

              <div className="space-y-6">
                <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black leading-tight">
                  <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-gradient">
                    Global Monitoring
                  </span>
                  <br />
                  <span className="text-foreground">That Pays You</span>
                </h1>

                <p className="text-xl sm:text-2xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
                  The world's first decentralized monitoring network where website owners{" "}
                  <span className="text-primary font-bold">earn money</span> while getting monitored by a global
                  community of validators.
                </p>
              </div>

              <div className="relative max-w-5xl mx-auto my-16">
                <Card className="backdrop-blur-sm bg-card/60 border-primary/30 shadow-2xl hover:shadow-primary/20 transition-all duration-500">
                  <CardContent className="p-8">
                    <div className="text-center mb-6">
                      <h3 className="text-2xl font-bold text-foreground mb-2 flex items-center justify-center gap-2">
                        <Eye className="w-6 h-6 text-primary" />
                        Live Global Network
                      </h3>
                      <p className="text-muted-foreground">
                        Watch validators ping websites around the world in real-time
                      </p>
                    </div>

                    <div className="relative w-full h-80 bg-gradient-to-br from-primary/15 via-accent/10 to-primary/15 rounded-2xl overflow-hidden border border-primary/30 shadow-inner">
                      {/* World map background pattern */}
                      <div className="absolute inset-0 opacity-20">
                        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                          <defs>
                            <pattern id="worldGrid" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
                              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="currentColor" strokeWidth="0.5" />
                            </pattern>
                          </defs>
                          <rect width="100" height="100" fill="url(#worldGrid)" />
                        </svg>
                      </div>

                      {/* Active ping locations */}
                      {activePings.map((ping) => (
                        <div
                          key={ping.id}
                          className="absolute w-6 h-6 -translate-x-3 -translate-y-3"
                          style={{ left: `${ping.x}%`, top: `${ping.y}%` }}
                        >
                          <div
                            className={`w-6 h-6 rounded-full animate-ping ${ping.status === "success" ? "bg-primary" : "bg-warning"}`}
                          />
                          <div
                            className={`absolute inset-0 w-6 h-6 rounded-full animate-pulse ${ping.status === "success" ? "bg-accent" : "bg-orange-400"}`}
                          />
                          <div className="absolute -top-10 left-1/2 -translate-x-1/2 text-xs font-medium whitespace-nowrap bg-background/90 backdrop-blur-sm px-2 py-1 rounded border border-primary/20 shadow-lg">
                            <div className="text-primary">{ping.name}</div>
                            <div className="text-muted-foreground text-xs">{ping.country}</div>
                          </div>
                        </div>
                      ))}

                      {/* Connection lines between validators */}
                      <svg className="absolute inset-0 w-full h-full pointer-events-none">
                        <defs>
                          <linearGradient id="connectionGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.4" />
                            <stop offset="50%" stopColor="hsl(var(--accent))" stopOpacity="0.8" />
                            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.4" />
                          </linearGradient>
                        </defs>
                        {activePings.slice(0, 4).map((ping, index) => {
                          const nextPing = activePings[(index + 1) % Math.min(activePings.length, 4)]
                          if (!nextPing) return null
                          return (
                            <line
                              key={`line-${ping.id}`}
                              x1={`${ping.x}%`}
                              y1={`${ping.y}%`}
                              x2={`${nextPing.x}%`}
                              y2={`${nextPing.y}%`}
                              stroke="url(#connectionGradient)"
                              strokeWidth="2"
                              className="animate-pulse"
                              strokeDasharray="5,5"
                            />
                          )
                        })}
                      </svg>

                      {/* Network status indicator */}
                      <div className="absolute top-4 right-4 flex items-center gap-2 bg-background/80 backdrop-blur-sm px-3 py-2 rounded-lg border border-primary/20">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-xs font-medium text-foreground">Network Active</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-6 mt-8">
                      <div className="text-center group">
                        <div className="text-3xl font-bold text-primary group-hover:scale-110 transition-transform duration-300">
                          {globalStats.validators}
                        </div>
                        <div className="text-sm text-muted-foreground flex items-center justify-center gap-1">
                          <Shield className="w-3 h-3" />
                          Active Validators
                        </div>
                      </div>
                      <div className="text-center group">
                        <div className="text-3xl font-bold text-accent group-hover:scale-110 transition-transform duration-300">
                          {globalStats.websites}
                        </div>
                        <div className="text-sm text-muted-foreground flex items-center justify-center gap-1">
                          <Server className="w-3 h-3" />
                          Monitored Sites
                        </div>
                      </div>
                      <div className="text-center group">
                        <div className="text-3xl font-bold text-primary group-hover:scale-110 transition-transform duration-300">
                          {globalStats.pings.toLocaleString()}
                        </div>
                        <div className="text-sm text-muted-foreground flex items-center justify-center gap-1">
                          <Wifi className="w-3 h-3" />
                          Pings Today
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-8">
                <Button
                  onClick={handleGetStarted}
                  size="lg"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-xl hover:shadow-primary/40 group px-8 py-4 text-lg hover:scale-105 transition-all duration-300"
                >
                  Join the Revolution
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
                </Button>

                <Button
                  onClick={handleBecomeValidator}
                  variant="outline"
                  size="lg"
                  className="border-primary text-primary hover:bg-primary hover:text-primary-foreground group px-8 py-4 text-lg bg-transparent hover:scale-105 transition-all duration-300"
                >
                  <Shield className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform duration-300" />
                  Become a Validator
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="network" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold mb-6 text-foreground">How Our Network Works</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              A decentralized ecosystem where everyone benefits from global website monitoring
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              {
                icon: Globe,
                title: "Global Validators",
                description:
                  "Validators around the world continuously monitor websites and earn rewards for their service",
                color: "from-primary to-primary/80",
                stats: "247+ Active",
              },
              {
                icon: Activity,
                title: "Real-time Monitoring",
                description:
                  "Instant detection of downtime, performance issues, and security threats across the network",
                color: "from-accent to-accent/80",
                stats: "24/7 Coverage",
              },
              {
                icon: TrendingUp,
                title: "Earn While Monitored",
                description: "Website owners receive payments for participating in the network instead of paying fees",
                color: "from-green-500 to-green-600",
                stats: "Revenue Stream",
              },
            ].map((item, index) => (
              <Card
                key={index}
                className="backdrop-blur-sm bg-card/50 border-primary/20 hover:shadow-xl hover:shadow-primary/10 transition-all duration-300 group"
              >
                <CardContent className="p-8 text-center">
                  <div
                    className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${item.color} flex items-center justify-center mb-6 mx-auto shadow-lg group-hover:scale-110 transition-transform duration-300`}
                  >
                    <item.icon className="w-10 h-10 text-white" />
                  </div>
                  <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">{item.stats}</Badge>
                  <h3 className="text-2xl font-bold mb-4 text-foreground">{item.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="vision" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold mb-6 text-foreground">Our Vision</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Transforming website monitoring from a cost center into a revenue stream
            </p>
          </div>

          <div className="max-w-6xl mx-auto">
            <div className="grid lg:grid-cols-3 gap-8">
              {[
                {
                  icon: Target,
                  title: "The Problem",
                  description:
                    "Traditional monitoring services charge hundreds per month while providing basic uptime checks. Website owners pay for peace of mind, but get little value beyond alerts.",
                  color: "from-red-500 to-orange-500",
                },
                {
                  icon: Lightbulb,
                  title: "Our Solution",
                  description:
                    "WebTether flips the model. Website owners earn money while getting monitored. Validators earn rewards for providing monitoring services. Everyone wins in our decentralized network.",
                  color: "from-primary to-accent",
                },
                {
                  icon: Rocket,
                  title: "The Future",
                  description:
                    "A world where monitoring is profitable, decentralized, and more reliable than traditional services. Join us in building the future of web infrastructure.",
                  color: "from-purple-500 to-pink-500",
                },
              ].map((item, index) => (
                <Card
                  key={index}
                  className="backdrop-blur-sm bg-card/50 border-primary/20 h-full hover:shadow-xl hover:shadow-primary/10 transition-all duration-300 group"
                >
                  <CardContent className="p-8">
                    <div
                      className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${item.color} flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300`}
                    >
                      <item.icon className="w-8 h-8 text-white" />
                    </div>

                    <h3 className="text-2xl font-bold mb-4 text-foreground">{item.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{item.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold mb-6 text-foreground">Revolutionary Features</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Built from the ground up to reward participation and ensure reliability
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            {[
              {
                icon: DollarSign,
                title: "Earn While Monitored",
                description: "Get paid for having your website monitored instead of paying for it",
              },
              {
                icon: Shield,
                title: "Validator Network",
                description: "Earn rewards by validating other websites and contributing to network security",
              },
              {
                icon: Globe,
                title: "Global Coverage",
                description: "Decentralized validators worldwide provide 24/7 monitoring from every continent",
              },
              {
                icon: Zap,
                title: "Real-time Alerts",
                description: "Instant notifications when issues are detected by our validator network",
              },
            ].map((feature, index) => (
              <Card
                key={index}
                className="backdrop-blur-sm bg-card/50 border-primary/20 h-full text-center group hover:shadow-xl hover:shadow-primary/10 transition-all duration-300"
              >
                <CardContent className="p-8">
                  <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                    <feature.icon className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-4 text-foreground">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="early-access" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold mb-6 text-foreground">Join the Beta</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Be among the first to experience the future of website monitoring
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="backdrop-blur-sm bg-card/50 border-primary/20 shadow-2xl">
              <CardContent className="p-12 text-center">
                <div className="w-24 h-24 mx-auto mb-8 rounded-3xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-xl">
                  <Sparkles className="w-12 h-12 text-white" />
                </div>

                <h3 className="text-3xl font-bold mb-6 text-foreground">Early Adopter Benefits</h3>

                <div className="grid md:grid-cols-2 gap-6 mb-8 text-left">
                  {[
                    "Priority access to the platform",
                    "Exclusive early adopter rewards",
                    "Direct input on feature development",
                    "Lifetime discount on premium features",
                    "Special validator status opportunities",
                    "Community recognition as a pioneer",
                  ].map((benefit, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                      <span className="text-muted-foreground">{benefit}</span>
                    </div>
                  ))}
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <Button
                    onClick={handleGetStarted}
                    size="lg"
                    variant="secondary"
                    className="group bg-white text-primary hover:bg-white/90 px-8 py-4 text-lg shadow-xl"
                  >
                    Join Beta Waitlist
                    <ArrowRight className="w-6 h-6 ml-3 group-hover:translate-x-1 transition-transform duration-300" />
                  </Button>
                  <Button
                    onClick={handleBecomeValidator}
                    variant="outline"
                    size="lg"
                    className="group border-white text-white hover:bg-white hover:text-primary bg-transparent px-8 py-4 text-lg"
                  >
                    Become a Pioneer
                  </Button>
                </div>

                <p className="text-sm text-muted-foreground mt-6">
                  No commitment required • Be notified when we launch • Shape the future of monitoring
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-primary to-accent text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl sm:text-6xl font-black mb-8">Ready to Pioneer the Future?</h2>
            <p className="text-xl sm:text-2xl mb-12 opacity-90 leading-relaxed">
              Join the revolution that transforms monitoring from a cost into a revenue stream
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <Button
                onClick={handleGetStarted}
                size="lg"
                variant="secondary"
                className="group bg-white text-primary hover:bg-white/90 px-8 py-4 text-lg shadow-xl"
              >
                Join the Beta
                <ArrowRight className="w-6 h-6 ml-3 group-hover:translate-x-1 transition-transform duration-300" />
              </Button>

              <Button
                onClick={handleBecomeValidator}
                variant="outline"
                size="lg"
                className="group border-white text-white hover:bg-white hover:text-primary bg-transparent px-8 py-4 text-lg"
              >
                <Shield className="w-6 h-6 mr-3 group-hover:rotate-12 transition-transform duration-300" />
                Become a Pioneer
              </Button>
            </div>

            <p className="text-sm opacity-75 mt-8">Be part of history • Shape the future • Earn from day one</p>
          </div>
        </div>
      </section>

      <footer className="py-16 border-t border-primary/20 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center shadow-lg">
                <Network className="w-6 h-6 text-white" />
              </div>
              <div className="flex flex-col items-start">
                <span className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  WebTether
                </span>
                <span className="text-sm text-muted-foreground -mt-1">Global Monitoring Network</span>
              </div>
            </div>
            <p className="text-muted-foreground mb-6 text-lg">
              Pioneering the future of decentralized website monitoring
            </p>
            <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
              <span>© 2024 WebTether. Built for the</span>
              <span className="text-primary font-semibold">decentralized future</span>
            </div>
          </div>
        </div>
      </footer>

      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 z-40 w-14 h-14 backdrop-blur-sm bg-card/70 border border-primary/30 hover:shadow-xl hover:shadow-primary/30 text-primary rounded-2xl transition-all duration-300 flex items-center justify-center group hover:scale-110"
        >
          <ChevronUp className="w-6 h-6 group-hover:-translate-y-1 transition-transform duration-300" />
        </button>
      )}

      <LoginDialog
        open={showLoginDialog}
        onOpenChange={setShowLoginDialog}
        onSwitchToSignup={() => {
          setShowLoginDialog(false)
          setShowSignupDialog(true)
        }}
      />
      <SignupDialog
        open={showSignupDialog}
        onOpenChange={setShowSignupDialog}
        defaultIsValidator={showValidatorSignup}
        onSwitchToLogin={() => {
          setShowSignupDialog(false)
          setShowLoginDialog(true)
        }}
      />
    </div>
  )
}
