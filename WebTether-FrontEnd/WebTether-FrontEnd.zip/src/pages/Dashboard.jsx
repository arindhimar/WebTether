"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useAuth } from "../contexts/AuthContext"
import { websiteAPI, pingAPI } from "../services/api"
import { DashboardHeader } from "../components/dashboard/DashboardHeader"
import { StatsOverview } from "../components/dashboard/StatsOverview"
import { WebsiteList } from "../components/dashboard/WebsiteList"
import { UptimeChart } from "../components/dashboard/UptimeChart"
import { ValidatorActivities } from "../components/dashboard/ValidatorActivities"
import PingQueue from "../components/dashboard/PingQueue"
import AvailableSites from "../components/dashboard/AvailableSites"
import UserSettings from "../components/dashboard/UserSettings"
import { useToast } from "../hooks/use-toast"
import WalletPage from "./WalletPage"
import { WalletBalanceWidget } from "../components/WalletBalanceWidget"
import { Card } from "../components/ui/card"
import { Badge } from "../components/ui/badge"
import { TrendingUp, Wallet, Globe, Activity } from "lucide-react"

export default function Dashboard() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [websites, setWebsites] = useState([])
  const [pings, setPings] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)
  const [currentView, setCurrentView] = useState(user?.isVisitor ? "available-sites" : "overview")

  useEffect(() => {
    loadDashboardData()
  }, [user])

  useEffect(() => {
    const interval = setInterval(() => {
      loadDashboardData(true)
    }, 30000)

    return () => clearInterval(interval)
  }, [user])

  const loadDashboardData = async (silent = false) => {
    if (!user) return

    if (!silent) {
      setIsLoading(true)
      setError(null)
    }

    try {
      const [websitesResponse, pingsResponse] = await Promise.all([websiteAPI.getAllWebsites(), pingAPI.getAllPings()])

      const userWebsites = websitesResponse.filter((website) => website.uid === user.id)

      const processedWebsites = userWebsites.map((website) => {
        const websitePings = pingsResponse.filter((ping) => ping.wid === website.wid)
        const upPings = websitePings.filter((ping) => ping.is_up)

        let uptime = 0
        let uptimeDisplay = "No data"

        if (websitePings.length > 0) {
          uptime = (upPings.length / websitePings.length) * 100
          uptimeDisplay = `${Math.round(uptime * 10) / 10}%`
        }

        const lastPing = websitePings.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0]

        return {
          id: website.wid,
          wid: website.wid,
          url: website.url,
          name: website.url.replace(/^https?:\/\//, "").replace(/\/$/, ""),
          status: lastPing ? (lastPing.is_up ? "up" : "down") : "unknown",
          uptime: uptimeDisplay,
          uptimeValue: uptime,
          lastCheck: lastPing ? lastPing.created_at : website.created_at,
          responseTime: lastPing ? lastPing.latency_ms : null,
          category: website.category,
          pingCount: websitePings.length,
        }
      })

      setWebsites(processedWebsites)
      setPings(pingsResponse)
    } catch (error) {
      console.error("Error loading dashboard data:", error)
      if (!silent) {
        setError(error.message)
        toast({
          title: "Error Loading Data",
          description: "Failed to load dashboard data. Please try again.",
          variant: "destructive",
        })
      }
    } finally {
      if (!silent) {
        setIsLoading(false)
      }
    }
  }

  const handleNavigation = (view) => {
    setCurrentView(view)
  }

  const handleDataRefresh = () => {
    loadDashboardData()
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case "overview":
        return (
          <div className="space-y-8">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <Card className="p-6 glass-card">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Globe className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Listed Websites</p>
                    <p className="text-2xl font-bold">{websites.length}</p>
                  </div>
                </div>
              </Card>

              <Card className="p-6 glass-card">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-500/10 rounded-lg">
                    <TrendingUp className="w-5 h-5 text-green-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Pings</p>
                    <p className="text-2xl font-bold">{websites.reduce((sum, w) => sum + w.pingCount, 0)}</p>
                  </div>
                </div>
              </Card>

              <Card className="p-6 glass-card">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Wallet className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Estimated Earnings</p>
                    <p className="text-2xl font-bold text-green-600">
                      {(websites.reduce((sum, w) => sum + w.pingCount, 0) * 0.0001).toFixed(4)} ETH
                    </p>
                  </div>
                </div>
              </Card>

              <Card className="p-6 glass-card">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-500/10 rounded-lg">
                    <Activity className="w-5 h-5 text-purple-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Avg Uptime</p>
                    <p className="text-2xl font-bold">
                      {websites.length > 0
                        ? `${Math.round(websites.reduce((sum, w) => sum + (w.uptimeValue || 0), 0) / websites.length)}%`
                        : "N/A"}
                    </p>
                  </div>
                </div>
              </Card>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <Card className="p-6 glass-card">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-500" />
                  Earnings Breakdown
                </h3>
                <div className="space-y-4">
                  {websites.map((website) => (
                    <div key={website.wid} className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                      <div>
                        <p className="font-medium">{website.name}</p>
                        <p className="text-sm text-muted-foreground">{website.pingCount} pings</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-green-600">+{(website.pingCount * 0.0001).toFixed(4)} ETH</p>
                        <Badge variant={website.status === "up" ? "default" : "destructive"} className="text-xs">
                          {website.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                  {websites.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">
                      No websites listed yet. Add your first website to start earning!
                    </p>
                  )}
                </div>
              </Card>

              <div className="space-y-6">
                <UptimeChart websites={websites} pings={pings} />
              </div>
            </div>
          </div>
        )

      case "websites":
        return (
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-6">
              <WebsiteList
                websites={websites}
                setWebsites={setWebsites}
                onWebsiteAdded={handleDataRefresh}
                onWebsiteDeleted={handleDataRefresh}
              />
            </div>
            <div className="space-y-6">
              <UptimeChart websites={websites} pings={pings} />
            </div>
          </div>
        )

      case "available-sites":
        return <AvailableSites pings={pings} onPingAccepted={handleDataRefresh} />

      case "activity":
        return user?.isVisitor ? (
          <ValidatorActivities pings={pings} userId={user.id} />
        ) : (
          <PingQueue pings={pings} websites={websites} userId={user.id} onPingAccepted={handleDataRefresh} />
        )

      case "wallet":
        return <WalletPage />

      case "settings":
        return <UserSettings />

      default:
        return (
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-6">
              <WebsiteList
                websites={websites}
                setWebsites={setWebsites}
                onWebsiteAdded={handleDataRefresh}
                onWebsiteDeleted={handleDataRefresh}
              />
            </div>
            <div className="space-y-6">
              <UptimeChart websites={websites} pings={pings} />
            </div>
          </div>
        )
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <p className="text-destructive">Error: {error}</p>
          <button
            onClick={loadDashboardData}
            className="px-4 py-2 bg-primary text-primary-foreground rounded hover:bg-primary/90"
          >
            Retry
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader currentView={currentView} onNavigate={handleNavigation} />

      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-8"
        >
          <div className="flex justify-between items-start">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold gradient-text">Welcome back, {user?.name}!</h1>
              <p className="text-muted-foreground max-w-2xl">
                {user?.isVisitor
                  ? "Earn rewards by validating website uptime. Each ping you perform earns you ETH while helping maintain network reliability."
                  : "List your websites and earn ETH from every ping. The more reliable your sites, the more validators will check them."}
              </p>
            </div>

            <WalletBalanceWidget className="min-w-[280px]" />
          </div>

          <StatsOverview websites={websites} pings={pings} user={user} />

          <div className="space-y-6">{renderCurrentView()}</div>
        </motion.div>
      </main>
    </div>
  )
}
