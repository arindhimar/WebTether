"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { Badge } from "../components/ui/badge"
import { useAuth } from "../contexts/AuthContext"
import { useToast } from "../hooks/use-toast"
import { api } from "../services/api"
import { Wallet, Link, TrendingUp, TrendingDown, Clock, CheckCircle, XCircle } from "lucide-react"

// Generate 20 fake transaction codes
const FAKE_TX_CODES = Array.from({ length: 20 }, (_, i) => `TX-${String(i + 1).padStart(3, "0")}`)

export default function WalletPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [linkedWallet, setLinkedWallet] = useState(null)
  const [walletBalance, setWalletBalance] = useState(null)
  const [transactions, setTransactions] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [isLinking, setIsLinking] = useState(false)

  useEffect(() => {
    loadWalletData()
  }, [user])

  const loadWalletData = async () => {
    if (!user) return

    try {
      setIsLoading(true)

      // Load wallet balance and transaction history
      const [balanceResponse, transactionsResponse] = await Promise.all([
        api.getWalletBalance(),
        api.getTransactionHistory(),
      ])

      setWalletBalance(balanceResponse)
      setTransactions(transactionsResponse.transactions || [])

      // Check if user has a linked wallet (simulated)
      const savedWallet = localStorage.getItem(`wallet_${user.id}`)
      if (savedWallet) {
        setLinkedWallet(JSON.parse(savedWallet))
      }
    } catch (error) {
      console.error("Error loading wallet data:", error)
      toast({
        title: "Error Loading Wallet",
        description: "Failed to load wallet data. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleLinkWallet = async (txCode) => {
    setIsLinking(true)

    try {
      // Simulate wallet linking process
      await new Promise((resolve) => setTimeout(resolve, 1500))

      const walletData = {
        address: `0x${Math.random().toString(16).substr(2, 40)}`,
        txCode: txCode,
        linkedAt: new Date().toISOString(),
        network: "Hardhat Local",
      }

      // Save to localStorage (in real app, this would be saved to backend)
      localStorage.setItem(`wallet_${user.id}`, JSON.stringify(walletData))
      setLinkedWallet(walletData)

      window.dispatchEvent(new CustomEvent("walletLinked", { detail: walletData }))

      toast({
        title: "Wallet Linked Successfully!",
        description: `Your wallet has been linked with transaction code ${txCode}`,
      })

      // Refresh wallet data
      await loadWalletData()
    } catch (error) {
      toast({
        title: "Linking Failed",
        description: "Failed to link wallet. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLinking(false)
    }
  }

  const handleUnlinkWallet = () => {
    localStorage.removeItem(`wallet_${user.id}`)
    setLinkedWallet(null)

    window.dispatchEvent(new CustomEvent("walletUnlinked"))

    toast({
      title: "Wallet Unlinked",
      description: "Your wallet has been unlinked successfully.",
    })
  }

  const formatTransactionType = (type) => {
    switch (type) {
      case "ping_payment":
        return "Ping Reward"
      case "website_payment":
        return "Website Fee"
      default:
        return type
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-muted-foreground">Loading wallet data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-8"
      >
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Wallet className="h-8 w-8 text-blue-600" />
            Wallet Management
          </h1>
          <p className="text-muted-foreground">
            Link your wallet to seamlessly add websites and earn rewards from pings.
          </p>
        </div>

        {/* Wallet Status Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Wallet Status</span>
              {linkedWallet ? (
                <Badge variant="default" className="bg-green-100 text-green-800">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Linked
                </Badge>
              ) : (
                <Badge variant="secondary">
                  <XCircle className="h-3 w-3 mr-1" />
                  Not Linked
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              {linkedWallet ? "Your wallet is connected and ready to use" : "Link a wallet to start using the platform"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {linkedWallet ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Wallet Address</label>
                    <p className="font-mono text-sm bg-muted p-2 rounded">{linkedWallet.address}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Transaction Code</label>
                    <p className="font-mono text-sm bg-muted p-2 rounded">{linkedWallet.txCode}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Network</label>
                    <p className="text-sm">{linkedWallet.network}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Linked At</label>
                    <p className="text-sm">{new Date(linkedWallet.linkedAt).toLocaleString()}</p>
                  </div>
                </div>
                <Button variant="outline" onClick={handleUnlinkWallet}>
                  <Link className="h-4 w-4 mr-2" />
                  Unlink Wallet
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg">
                  <h3 className="font-medium text-blue-900 dark:text-blue-100 mb-2">🎓 Educational Mode</h3>
                  <p className="text-sm text-blue-800 dark:text-blue-200">
                    Select a transaction code to simulate wallet linking. This connects your account to our test
                    blockchain for seamless payments and rewards.
                  </p>
                </div>

                <div className="space-y-3">
                  <label className="text-sm font-medium">Select Transaction Code to Link:</label>
                  <div className="grid grid-cols-4 md:grid-cols-5 gap-2">
                    {FAKE_TX_CODES.map((code) => (
                      <Button
                        key={code}
                        variant="outline"
                        size="sm"
                        onClick={() => handleLinkWallet(code)}
                        disabled={isLinking}
                        className="font-mono text-xs"
                      >
                        {code}
                      </Button>
                    ))}
                  </div>
                </div>

                {isLinking && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                    Linking wallet...
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Balance Card */}
        {walletBalance && (
          <Card>
            <CardHeader>
              <CardTitle>Wallet Balance</CardTitle>
              <CardDescription>Your current balance and transaction summary</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{walletBalance.eth_balance} ETH</div>
                  <div className="text-sm text-muted-foreground">≈ ${walletBalance.usd_value}</div>
                  <div className="text-xs text-muted-foreground mt-1">Current Balance</div>
                </div>

                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{walletBalance.total_pings}</div>
                  <div className="text-sm text-muted-foreground">Total Pings</div>
                </div>

                <div className="text-center">
                  <div className={`font-medium ${walletBalance.total_spent >= 0 ? "text-green-600" : "text-red-600"}`}>
                    {walletBalance.total_spent >= 0 ? "+" : "-"}
                    {Math.abs(walletBalance.total_spent)} ETH
                  </div>
                  <div className="text-sm text-muted-foreground">Total Activity</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Transaction History */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Transaction History
            </CardTitle>
            <CardDescription>Your recent transactions and activities</CardDescription>
          </CardHeader>
          <CardContent>
            {transactions.length > 0 ? (
              <div className="space-y-3">
                {transactions.slice(0, 10).map((tx, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div
                        className={`p-2 rounded-full ${
                          tx.type === "ping_payment" ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"
                        }`}
                      >
                        {tx.type === "ping_payment" ? (
                          <TrendingUp className="h-4 w-4" />
                        ) : (
                          <TrendingDown className="h-4 w-4" />
                        )}
                      </div>
                      <div>
                        <div className="font-medium">{formatTransactionType(tx.type)}</div>
                        <div className="text-sm text-muted-foreground font-mono">{tx.tx_hash}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`font-medium ${tx.type === "ping_payment" ? "text-green-600" : "text-red-600"}`}>
                        {tx.type === "ping_payment" ? "+" : "-"}
                        {tx.amount} ETH
                      </div>
                      <div className="text-sm text-muted-foreground">{new Date(tx.timestamp).toLocaleDateString()}</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Wallet className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No transactions yet</p>
                <p className="text-sm">Start by adding a website or pinging sites to see activity</p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
