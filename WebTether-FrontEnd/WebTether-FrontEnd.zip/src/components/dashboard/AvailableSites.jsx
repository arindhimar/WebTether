"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card"
import { Button } from "../ui/button"
import { Badge } from "../ui/badge"
import { useAuth } from "../../contexts/AuthContext"
import { api } from "../../services/api"
import { useToast } from "../../hooks/use-toast"
import { isCloudflareWorkerConfigured } from "../../utils/cloudflareAgent"
import { localWeb3Service } from "../../utils/web3"
import { Globe, Zap, Clock, MapPin, Cloud, Coins, Wallet, AlertCircle, Server } from 'lucide-react'

export default function AvailableSites({ onPingAccepted }) {
  const { user } = useAuth()
  const { toast } = useToast()
  const [sites, setSites] = useState([])
  const [loading, setLoading] = useState(true)
  const [pingingStates, setPingingStates] = useState({})
  const [web3Connected, setWeb3Connected] = useState(false)
  const [walletAddress, setWalletAddress] = useState("")
  const [ethBalance, setEthBalance] = useState("0")
  const [localNodeRunning, setLocalNodeRunning] = useState(false)

  useEffect(() => {
    fetchAvailableSites()
    checkLocalNode()
  }, [])

  const fetchAvailableSites = async () => {
    try {
      const data = await api.getAvailableSites()
      setSites(data)
    } catch (error) {
      console.error("Failed to fetch available sites:", error)
      toast({
        title: "Error",
        description: "Failed to load available sites",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const checkLocalNode = async () => {
    const isRunning = await localWeb3Service.isLocalNodeRunning()
    setLocalNodeRunning(isRunning)
    
    if (!isRunning) {
      toast({
        title: "Local Node Not Running",
        description: "Please start your Hardhat node on http://localhost:8545",
        variant: "destructive",
      })
    }
  }

  const connectToLocalBlockchain = async () => {
    try {
      const address = await localWeb3Service.connectToLocal()
      setWalletAddress(address)
      setWeb3Connected(true)
      
      const balance = await localWeb3Service.getBalance(address)
      setEthBalance(balance)
      
      toast({
        title: "Connected to Local Blockchain",
        description: `Connected with address ${address.slice(0, 6)}...${address.slice(-4)}`,
      })
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleManualPing = async (site) => {
    if (!user?.id) {
      toast({
        title: "Error",
        description: "Please log in to ping websites",
        variant: "destructive",
      })
      return
    }

    if (!isCloudflareWorkerConfigured(user)) {
      toast({
        title: "Worker Not Configured",
        description: "Please configure your Cloudflare Worker in settings first",
        variant: "destructive",
      })
      return
    }

    if (!web3Connected) {
      toast({
        title: "Blockchain Not Connected",
        description: "Please connect to the local blockchain first",
        variant: "destructive",
      })
      return
    }

    if (!localNodeRunning) {
      toast({
        title: "Local Node Required",
        description: "Please start your Hardhat node on http://localhost:8545",
        variant: "destructive",
      })
      return
    }

    setPingingStates((prev) => ({ ...prev, [site.wid]: true }))

    try {
      // Step 1: Record ping on blockchain
      toast({
        title: "Recording on Blockchain",
        description: "Sending transaction to local Hardhat network...",
      })

      const pingFee = "0.001" // 0.001 ETH fee
      const txResult = await localWeb3Service.recordPing(
        site.wid,
        user.id,
        pingFee
      )

      const txHash = txResult.hash
      const amountPaid = txResult.amountPaid

      toast({
        title: "Transaction Confirmed",
        description: `TX: ${txHash.slice(0, 10)}... | Fee: ${amountPaid} ETH`,
      })

      // Step 2: Call backend with transaction proof
      toast({
        title: "Recording Ping",
        description: "Submitting ping request to backend...",
      })

      const pingData = {
        wid: site.wid,
        url: site.url,
        tx_hash: txHash,
        fee_paid_numeric: parseFloat(amountPaid)
      }

      const result = await api.request("/pings/manual", {
        method: "POST",
        body: JSON.stringify(pingData),
      })

      // Step 3: Handle response
      if (result.status === "recorded" && result.result) {
        const { is_up, latency_ms, region } = result.result

        toast({
          title: is_up ? "Site is UP! 🟢" : "Site is DOWN 🔴",
          description: (
            <div className="space-y-1">
              <p><strong>URL:</strong> {site.url}</p>
              <p><strong>Latency:</strong> {latency_ms}ms</p>
              <p><strong>Region:</strong> {region}</p>
              <p><strong>Fee Paid:</strong> {amountPaid} ETH</p>
              <p><strong>TX Hash:</strong> {txHash.slice(0, 16)}...</p>
              <p><strong>Reward:</strong> +5 points earned!</p>
            </div>
          ),
          variant: is_up ? "default" : "destructive",
        })

        // Update ETH balance
        const newBalance = await localWeb3Service.getBalance(walletAddress)
        setEthBalance(newBalance)

      } else {
        toast({
          title: "Ping Completed",
          description: `Ping recorded successfully. Fee: ${amountPaid} ETH`,
        })
      }

      // Trigger data refresh
      if (onPingAccepted) {
        onPingAccepted()
      }

    } catch (error) {
      console.error("Manual ping failed:", error)
      
      let errorMessage = error.message || "Failed to ping the website"
      
      // Handle specific error cases
      if (error.message.includes("402")) {
        errorMessage = "Payment verification failed. Please try again."
      } else if (error.message.includes("insufficient")) {
        errorMessage = "Insufficient ETH for transaction"
      } else if (error.message.includes("Contract call failed")) {
        errorMessage = "Smart contract interaction failed"
      }
      
      toast({
        title: "Ping Failed",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setPingingStates((prev) => ({ ...prev, [site.wid]: false }))
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Available Sites to Ping
          </CardTitle>
          <CardDescription>Loading available websites...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-16 bg-gray-200 rounded-lg"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!isCloudflareWorkerConfigured(user)) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Available Sites to Ping
          </CardTitle>
          <CardDescription>Configure your Cloudflare Worker to start pinging websites</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Cloud className="h-12 w-12 text-orange-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Cloudflare Worker Required</h3>
            <p className="text-muted-foreground mb-4">
              You need to configure your Cloudflare Worker to ping websites and earn rewards.
            </p>
            <Button
              className="bg-orange-500 hover:bg-orange-600"
              onClick={() => window.location.href = "/dashboard?view=settings"}
            >
              <Cloud className="h-4 w-4 mr-2" />
              Configure Worker
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Local Blockchain Connection Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="h-5 w-5" />
            Local Blockchain Connection
          </CardTitle>
          <CardDescription>Connect to your local Hardhat node to pay ping fees</CardDescription>
        </CardHeader>
        <CardContent>
          {!localNodeRunning ? (
            <div className="flex items-center justify-between p-4 border rounded-lg bg-red-50">
              <div className="flex items-center gap-3">
                <AlertCircle className="h-5 w-5 text-red-500" />
                <div>
                  <p className="font-medium text-red-800">Local Node Not Running</p>
                  <p className="text-sm text-red-600">Start Hardhat node: npx hardhat node</p>
                </div>
              </div>
              <Button onClick={checkLocalNode} variant="outline">
                <Server className="h-4 w-4 mr-2" />
                Check Again
              </Button>
            </div>
          ) : !web3Connected ? (
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <AlertCircle className="h-5 w-5 text-amber-500" />
                <div>
                  <p className="font-medium">Blockchain Not Connected</p>
                  <p className="text-sm text-muted-foreground">Connect to local Hardhat network</p>
                </div>
              </div>
              <Button onClick={connectToLocalBlockchain}>
                <Wallet className="h-4 w-4 mr-2" />
                Connect to Local Chain
              </Button>
            </div>
          ) : (
            <div className="flex items-center justify-between p-4 border rounded-lg bg-green-50">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <div>
                  <p className="font-medium">Connected to Local Blockchain</p>
                  <p className="text-sm text-muted-foreground">
                    {walletAddress.slice(0, 6)}...{walletAddress.slice(-4)}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium">{parseFloat(ethBalance).toFixed(4)} ETH</p>
                <p className="text-sm text-muted-foreground">Available balance</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Available Sites */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Available Sites to Ping
          </CardTitle>
          <CardDescription>Ping websites using your Cloudflare Worker and earn rewards (0.001 ETH per ping)</CardDescription>
        </CardHeader>
        <CardContent>
          {sites.length === 0 ? (
            <div className="text-center py-8">
              <Globe className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Sites Available</h3>
              <p className="text-muted-foreground">No websites are currently available for pinging. Check back later!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {sites.map((site) => (
                <div
                  key={site.wid}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Globe className="h-4 w-4 text-gray-500" />
                      <span className="font-medium">{site.url}</span>
                      {site.category && (
                        <Badge variant="secondary" className="text-xs">
                          {site.category}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        Ping from your location
                      </span>
                      <span className="flex items-center gap-1">
                        <Coins className="h-3 w-3" />
                        +5 points reward
                      </span>
                      <span className="flex items-center gap-1">
                        <Server className="h-3 w-3" />
                        0.001 ETH fee
                      </span>
                    </div>
                  </div>

                  <Button
                    onClick={() => handleManualPing(site)}
                    disabled={pingingStates[site.wid] || !web3Connected || !localNodeRunning}
                    className="bg-blue-500 hover:bg-blue-600"
                  >
                    {pingingStates[site.wid] ? (
                      <>
                        <Clock className="h-4 w-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Zap className="h-4 w-4 mr-2" />
                        Ping (0.001 ETH)
                      </>
                    )}
                  </Button>
                </div>
              ))}
            </div>
          )}

          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
            <div className="flex items-start gap-2">
              <Server className="h-4 w-4 text-blue-500 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-blue-800">Local Development Setup</p>
                <p className="text-blue-700">
                  Payments are processed through your local Hardhat blockchain. Each ping costs 0.001 ETH and is recorded on-chain.
                  Make sure your Hardhat node is running on http://localhost:8545
                </p>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-orange-50 border border-orange-200 rounded-md">
            <div className="flex items-start gap-2">
              <Cloud className="h-4 w-4 text-orange-500 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-orange-800">Using your Cloudflare Worker</p>
                <p className="text-orange-700">
                  Pings are executed from your configured Cloudflare Worker:
                  <code className="bg-orange-100 px-1 rounded ml-1">{user?.agent_url}</code>
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
