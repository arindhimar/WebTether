"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card"
import { Globe, TrendingUp, Wallet, CheckCircle, Activity } from "lucide-react"

export function StatsOverview({ websites, pings, user }) {
  const totalWebsites = websites.length

  // Calculate average uptime only for websites that have been pinged
  const websitesWithPings = websites.filter((site) => site.pingCount > 0)
  const averageUptime =
    websitesWithPings.length > 0
      ? (websitesWithPings.reduce((sum, site) => sum + site.uptimeValue, 0) / websitesWithPings.length).toFixed(1)
      : "No data"

  const activeWebsites = websites.filter((site) => site.status === "up").length

  // Calculate total earnings for website owners
  const totalPings = websites.reduce((sum, site) => sum + site.pingCount, 0)
  const totalEarnings = totalPings * 0.0001 // 0.0001 ETH per ping
  const listingCosts = totalWebsites * 0.001 // 0.001 ETH per website
  const netEarnings = totalEarnings - listingCosts

  // Validator stats
  const userPings = pings.filter((ping) => ping.uid === user?.id)
  const successfulPings = userPings.filter((ping) => ping.is_up).length
  const validatorSuccessRate = userPings.length > 0 ? ((successfulPings / userPings.length) * 100).toFixed(1) : "0"
  const validatorEarnings = userPings.length * 0.0001 // Validators earn 0.0001 ETH per ping

  const stats = user?.isVisitor
    ? [
        {
          title: "Sites Validated",
          value: userPings.length,
          icon: Globe,
          color: "from-primary to-blue-600",
          description: "Total pings performed",
        },
        {
          title: "Success Rate",
          value: `${validatorSuccessRate}%`,
          icon: TrendingUp,
          color: "from-green-500 to-emerald-400",
          description: "Successful validations",
        },
        {
          title: "ETH Earned",
          value: `${validatorEarnings.toFixed(4)}`,
          icon: Wallet,
          color: "from-amber-500 to-orange-400",
          description: "Total validator rewards",
        },
      ]
    : [
        {
          title: "Listed Websites",
          value: totalWebsites,
          icon: Globe,
          color: "from-primary to-blue-600",
          description: "Active monitoring",
        },
        {
          title: "Total Pings",
          value: totalPings,
          icon: Activity,
          color: "from-purple-500 to-indigo-400",
          description: "Validation checks",
        },
        {
          title: "Net Earnings",
          value: `${netEarnings >= 0 ? "+" : ""}${netEarnings.toFixed(4)} ETH`,
          icon: Wallet,
          color: netEarnings >= 0 ? "from-green-500 to-emerald-400" : "from-red-500 to-rose-400",
          description: "After listing costs",
        },
        {
          title: "Active Sites",
          value: `${activeWebsites}/${totalWebsites}`,
          icon: CheckCircle,
          color: "from-blue-500 to-cyan-400",
          description: "Currently online",
        },
      ]

  return (
    <div className={`grid gap-4 ${user?.isVisitor ? "md:grid-cols-3" : "md:grid-cols-2 lg:grid-cols-4"}`}>
      {stats.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <Card className="glass-card hover:border-primary/20 transition-all duration-300 group">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="space-y-1">
                <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
                <p className="text-xs text-muted-foreground">{stat.description}</p>
              </div>
              <div
                className={`p-2 rounded-lg bg-gradient-to-br ${stat.color} group-hover:scale-110 transition-transform duration-300`}
              >
                <stat.icon className="h-4 w-4 text-white" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}
