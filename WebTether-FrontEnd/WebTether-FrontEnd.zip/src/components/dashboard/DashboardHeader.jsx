"use client"

import { Button } from "../ui/button"
import { ThemeToggle } from "../ui/theme-toggle"
import { UserMenu } from "../auth/UserMenu"
import { useAuth } from "../../contexts/AuthContext"
import { Wifi, BarChart3, Globe, Activity, Wallet, Zap } from "lucide-react"

export function DashboardHeader({ currentView, onNavigate }) {
  const { user } = useAuth()

  const getViewTitle = (view) => {
    switch (view) {
      case "overview":
        return "Dashboard Overview"
      case "websites":
        return "My Websites"
      case "available-sites":
        return "Available Sites"
      case "activity":
        return user?.isVisitor ? "My Activity" : "Ping Queue"
      case "wallet":
        return "Wallet Management"
      case "settings":
        return "Settings"
      default:
        return "Dashboard"
    }
  }

  const navigationTabs = [
    {
      key: "overview",
      label: "Overview",
      icon: BarChart3,
      show: !user?.isVisitor,
    },
    {
      key: "websites",
      label: "My Websites",
      icon: Globe,
      show: !user?.isVisitor,
    },
    {
      key: "available-sites",
      label: "Available Sites",
      icon: Zap,
      show: true,
    },
    {
      key: "activity",
      label: user?.isVisitor ? "My Activity" : "Ping Queue",
      icon: Activity,
      show: true,
    },
    {
      key: "wallet",
      label: "Wallet",
      icon: Wallet,
      show: true,
    },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        {/* Logo & Brand */}
        <div className="flex items-center space-x-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-blue-600">
            <Wifi className="h-5 w-5 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold gradient-text">WebTether</span>
            <span className="text-xs text-muted-foreground">{getViewTitle(currentView)}</span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center space-x-1">
          {navigationTabs
            .filter((tab) => tab.show)
            .map((tab) => (
              <Button
                key={tab.key}
                variant={currentView === tab.key ? "default" : "ghost"}
                size="sm"
                onClick={() => onNavigate(tab.key)}
                className={`flex items-center gap-2 ${
                  currentView === tab.key
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-accent hover:text-accent-foreground"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="hidden lg:inline">{tab.label}</span>
              </Button>
            ))}
        </nav>

        {/* User Info & Actions */}
        <div className="flex items-center space-x-4">
          <div className="hidden lg:flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">
              {user?.isVisitor ? "Validator Account" : "Website Owner"}
            </span>
            <div className="h-4 w-px bg-border" />
          </div>
          <ThemeToggle />
          <UserMenu currentView={currentView} onNavigate={onNavigate} />
        </div>
      </div>
    </header>
  )
}
