"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Button } from "../ui/button"
import { Input } from "../ui/input"
import { Label } from "../ui/label"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../ui/dialog"
import { useToast } from "../../hooks/use-toast"
import { useAuth } from "../../contexts/AuthContext"
import { websiteAPI } from "../../services/api"
import { Loader2, Globe, Coins, CreditCard } from "lucide-react"

const FAKE_TX_CODES = Array.from({ length: 20 }, (_, i) => `TX-${String(i + 1).padStart(3, "0")}`)
const WEBSITE_CREATION_COST = 0.001 // ETH cost to add a website

export function AddWebsiteDialog({ open, onOpenChange, onWebsiteAdded }) {
  const [formData, setFormData] = useState({
    url: "",
    category: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [linkedWallet, setLinkedWallet] = useState(null)
  const { user } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    if (open && user) {
      const savedWallet = localStorage.getItem(`wallet_${user.id}`)
      if (savedWallet) {
        setLinkedWallet(JSON.parse(savedWallet))
      } else {
        setLinkedWallet(null)
      }
    }
  }, [open, user])

  const validateUrl = (url) => {
    try {
      new URL(url)
      return true
    } catch {
      return false
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!validateUrl(formData.url)) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid URL (e.g., https://example.com)",
        variant: "destructive",
      })
      return
    }

    if (!linkedWallet) {
      toast({
        title: "Wallet Not Linked",
        description: "Please link your wallet first to add websites.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const response = await websiteAPI.createWebsite({
        url: formData.url,
        category: formData.category || null,
        tx_hash: linkedWallet.txCode, // Use linked wallet's transaction code
        fee_paid_numeric: WEBSITE_CREATION_COST,
      })

      toast({
        title: "Website Added Successfully!",
        description: `${formData.url} is now being monitored. Payment of ${WEBSITE_CREATION_COST} ETH processed.`,
      })

      setFormData({ url: "", category: "" }) // Removed txCode from reset
      onOpenChange(false)

      if (onWebsiteAdded) {
        onWebsiteAdded()
      }
    } catch (error) {
      console.error("Error adding website:", error)
      toast({
        title: "Failed to Add Website",
        description: error.message || "Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-blue-600" />
            Add New Website
          </DialogTitle>
          <DialogDescription>
            Add a website to monitor its uptime. <strong>Cost: {WEBSITE_CREATION_COST} ETH</strong>
          </DialogDescription>
        </DialogHeader>

        <motion.form
          onSubmit={handleSubmit}
          className="space-y-4 mt-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="space-y-2">
            <Label htmlFor="url">Website URL *</Label>
            <Input
              id="url"
              type="url"
              placeholder="https://example.com"
              value={formData.url}
              onChange={(e) => setFormData((prev) => ({ ...prev, url: e.target.value }))}
              required
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category (Optional)</Label>
            <Input
              id="category"
              placeholder="e.g., E-commerce, Blog, API"
              value={formData.category}
              onChange={(e) => setFormData((prev) => ({ ...prev, category: e.target.value }))}
              disabled={isLoading}
            />
          </div>

          <div
            className={`space-y-2 p-4 border rounded-lg ${
              linkedWallet ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <CreditCard className={`h-4 w-4 ${linkedWallet ? "text-green-600" : "text-red-600"}`} />
              <Label className={`font-medium ${linkedWallet ? "text-green-800" : "text-red-800"}`}>
                {linkedWallet ? "Wallet Linked" : "Wallet Required"}
              </Label>
            </div>
            {linkedWallet ? (
              <div>
                <p className="text-sm text-green-700 mb-2">✅ Payment will be processed using your linked wallet</p>
                <div className="text-xs text-green-600 font-mono bg-green-100 p-2 rounded">
                  Wallet: {linkedWallet.address.slice(0, 10)}...{linkedWallet.address.slice(-8)}
                </div>
              </div>
            ) : (
              <div>
                <p className="text-sm text-red-700 mb-2">❌ Please link your wallet first to add websites</p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => window.dispatchEvent(new CustomEvent("navigateToWallet"))}
                  className="text-red-600 border-red-300 hover:bg-red-50"
                >
                  Link Wallet
                </Button>
              </div>
            )}
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            disabled={isLoading || !linkedWallet}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing Payment...
              </>
            ) : (
              <>
                <Coins className="mr-2 h-4 w-4" />
                Pay {WEBSITE_CREATION_COST} ETH & Add Website
              </>
            )}
          </Button>
        </motion.form>

        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-700">
            💡 <strong>New Economic Model:</strong> You pay to add websites, but earn rewards when you ping them!
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}
