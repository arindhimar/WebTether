"use client"

import { useTheme } from "next-themes"
import { Toaster as Sonner } from "sonner"

const Toaster = ({ ...props }) => {
  const { theme = "system" } = useTheme()

  return (
    <Sonner
      theme={theme}
      className="toaster group"
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-white group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-2xl group-[.toaster]:backdrop-blur-xl group-[.toaster]:bg-white/90 dark:group-[.toaster]:bg-gray-900/90 group-[.toaster]:rounded-2xl group-[.toaster]:border-2",
          description: "group-[.toast]:text-muted-foreground",
          actionButton:
            "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground group-[.toast]:rounded-xl group-[.toast]:font-semibold group-[.toast]:shadow-lg hover:group-[.toast]:shadow-xl group-[.toast]:transition-all group-[.toast]:duration-300",
          cancelButton:
            "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground group-[.toast]:rounded-xl group-[.toast]:font-semibold hover:group-[.toast]:bg-muted/80 group-[.toast]:transition-all group-[.toast]:duration-300",
          success:
            "group-[.toast]:border-emerald-200 group-[.toast]:bg-emerald-50/90 dark:group-[.toast]:border-emerald-800 dark:group-[.toast]:bg-emerald-950/20",
          error:
            "group-[.toast]:border-red-200 group-[.toast]:bg-red-50/90 dark:group-[.toast]:border-red-800 dark:group-[.toast]:bg-red-950/20",
          warning:
            "group-[.toast]:border-amber-200 group-[.toast]:bg-amber-50/90 dark:group-[.toast]:border-amber-800 dark:group-[.toast]:bg-amber-950/20",
          info: "group-[.toast]:border-blue-200 group-[.toast]:bg-blue-50/90 dark:group-[.toast]:border-blue-800 dark:group-[.toast]:bg-blue-950/20",
        },
      }}
      {...props}
    />
  )
}

export { Toaster }
