"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "./ui/card"
import { Badge } from "./ui/badge"
import { Separator } from "./ui/separator"
import { useAuth } from "../contexts/AuthContext"
import { api } from "../services/api"
import { Wallet, TrendingUp, TrendingDown } from "lucide-react"
import { Button } from "./ui/button"

export function WalletBalanceWidget({ className = "" }) {
  const { user } = useAuth()
  const [walletBalance, setWalletBalance] = useState(null)
  const [transactions, setTransactions] = useState([])
  const [showTransactions, setShowTransactions] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [linkedWallet, setLinkedWallet] = useState(null)

  useEffect(() => {
    loadWalletData()
    checkLinkedWallet()
  }, [user])

  const loadWalletData = async () => {
    if (!user) return

    try {
      const [balanceResponse, transactionsResponse] = await Promise.all([
        api.getWalletBalance(),
        api.getTransactionHistory(),
      ])

      setWalletBalance(balanceResponse)
      setTransactions(transactionsResponse.transactions || [])
    } catch (error) {
      console.error("Error loading wallet data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const checkLinkedWallet = () => {
    if (!user) return

    const savedWallet = localStorage.getItem(`wallet_${user.id}`)
    if (savedWallet) {
      setLinkedWallet(JSON.parse(savedWallet))
    } else {
      setLinkedWallet(null)
    }
  }

  useEffect(() => {
    const handleStorageChange = () => {
      checkLinkedWallet()
    }

    window.addEventListener("storage", handleStorageChange)
    // Also listen for custom wallet events
    window.addEventListener("walletLinked", handleStorageChange)
    window.addEventListener("walletUnlinked", handleStorageChange)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("walletLinked", handleStorageChange)
      window.removeEventListener("walletUnlinked", handleStorageChange)
    }
  }, [user])

  const formatTransactionType = (type) => {
    switch (type) {
      case "ping_payment":
        return "Ping Reward"
      case "website_payment":
        return "Website Fee"
      default:
        return type
    }
  }

  if (isLoading || !walletBalance) {
    return (
      <Card className={`${className} cursor-pointer`}>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
            <span className="text-sm text-muted-foreground">Loading wallet...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="relative">
      <Card
        className={`${className} cursor-pointer transition-all hover:shadow-md`}
        onMouseEnter={() => setShowTransactions(true)}
        onMouseLeave={() => setShowTransactions(false)}
      >
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-full">
                <Wallet className="h-4 w-4 text-blue-600" />
              </div>
              <div>
                <div className="font-semibold text-lg">{walletBalance.eth_balance} ETH</div>
                <div className="text-sm text-muted-foreground">≈ ${walletBalance.usd_value}</div>
              </div>
            </div>

            <div className="text-right">
              {linkedWallet ? (
                <Badge variant="default" className="bg-green-100 text-green-800 text-xs">
                  Linked
                </Badge>
              ) : (
                <Badge variant="secondary" className="text-xs">
                  Not Linked
                </Badge>
              )}
              <div className="text-xs text-muted-foreground mt-1">{walletBalance.total_pings} pings</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Transaction History Popup */}
      {showTransactions && (
        <Card className="absolute top-full left-0 right-0 mt-2 z-50 shadow-lg border-2">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-sm">Recent Transactions</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => (window.location.href = "/dashboard?view=wallet")}
                className="text-xs"
              >
                View All
              </Button>
            </div>

            <Separator className="mb-3" />

            {transactions.length > 0 ? (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {transactions.slice(0, 5).map((tx, index) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div
                        className={`p-1 rounded-full ${
                          tx.type === "ping_payment" ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"
                        }`}
                      >
                        {tx.type === "ping_payment" ? (
                          <TrendingUp className="h-3 w-3" />
                        ) : (
                          <TrendingDown className="h-3 w-3" />
                        )}
                      </div>
                      <div>
                        <div className="font-medium">{formatTransactionType(tx.type)}</div>
                        <div className="text-xs text-muted-foreground">
                          {new Date(tx.timestamp).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <div className={`font-medium ${tx.type === "ping_payment" ? "text-green-600" : "text-red-600"}`}>
                      {tx.type === "ping_payment" ? "+" : "-"}
                      {tx.amount} ETH
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 text-muted-foreground">
                <p className="text-sm">No transactions yet</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
