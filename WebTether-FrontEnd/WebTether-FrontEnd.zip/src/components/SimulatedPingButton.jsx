"use client"

import { useState, useEffect } from "react"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Coins, TrendingUp, Wallet, Link } from "lucide-react"
import { api } from "../services/api"
import { useAuth } from "../contexts/AuthContext"

const PING_REWARD = 0.0001 // ETH reward for each ping

export function SimulatedPingButton({ wid, url, toast, onPingComplete }) {
  const { user } = useAuth()
  const [linkedWallet, setLinkedWallet] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [lastResult, setLastResult] = useState(null)

  useEffect(() => {
    checkLinkedWallet()

    // Listen for wallet linking events
    const handleWalletLinked = () => checkLinkedWallet()
    const handleWalletUnlinked = () => checkLinkedWallet()

    window.addEventListener("walletLinked", handleWalletLinked)
    window.addEventListener("walletUnlinked", handleWalletUnlinked)
    window.addEventListener("storage", handleWalletLinked)

    return () => {
      window.removeEventListener("walletLinked", handleWalletLinked)
      window.removeEventListener("walletUnlinked", handleWalletUnlinked)
      window.removeEventListener("storage", handleWalletLinked)
    }
  }, [user])

  const checkLinkedWallet = () => {
    if (!user) return

    const savedWallet = localStorage.getItem(`wallet_${user.id}`)
    if (savedWallet) {
      setLinkedWallet(JSON.parse(savedWallet))
    } else {
      setLinkedWallet(null)
    }
  }

  const handleSimulatePing = async () => {
    if (!linkedWallet) {
      toast({
        title: "Wallet Not Linked",
        description: "Please link your wallet first to earn rewards from pings",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      toast({
        title: "Processing Ping",
        description: `Earning ${PING_REWARD} ETH for ping using your linked wallet...`,
      })

      const result = await api.manualPing({
        wid,
        url,
        tx_hash: linkedWallet.txCode, // Use linked wallet's transaction code automatically
      })

      setLastResult(result)

      if (result.status === "recorded" && result.result) {
        const { is_up, latency_ms, region } = result.result

        toast({
          title: is_up ? "Site is UP! 🟢 Reward Earned!" : "Site is DOWN 🔴 Reward Earned!",
          description: (
            <div className="space-y-1">
              <p>
                <strong>URL:</strong> {url}
              </p>
              <p>
                <strong>Status:</strong> {is_up ? "Online" : "Offline"}
              </p>
              <p>
                <strong>Latency:</strong> {latency_ms}ms
              </p>
              <p>
                <strong>Region:</strong> {region}
              </p>
              <p>
                <strong>Wallet:</strong> {linkedWallet.address.slice(0, 10)}...{linkedWallet.address.slice(-8)}
              </p>
              <p className="text-green-600 font-semibold">💰 Earned: +{PING_REWARD} ETH</p>
            </div>
          ),
          variant: "default", // Always positive since user earns money
        })
      } else {
        toast({
          title: "Ping Completed - Reward Earned!",
          description: `Ping recorded using your linked wallet. You earned ${PING_REWARD} ETH!`,
        })
      }

      // Call callback to refresh data
      if (onPingComplete) {
        onPingComplete()
      }
    } catch (error) {
      console.error("Simulated ping failed:", error)

      let errorMessage = error.message || "Check console for details"

      // Handle specific error cases
      if (error.message?.includes("402")) {
        errorMessage = "Transaction verification failed on backend"
      } else if (error.message?.includes("Invalid transaction")) {
        errorMessage = "Invalid transaction code"
      } else if (error.message?.includes("already used")) {
        errorMessage = "This transaction code has already been used"
      }

      toast({
        title: "Ping Failed",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleNavigateToWallet = () => {
    window.dispatchEvent(new CustomEvent("navigateToWallet"))
  }

  return (
    <div className="space-y-4">
      {/* Educational Notice - Updated for new economic model */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-3">
        <div className="flex items-center gap-2 text-green-800 text-sm">
          <Coins className="h-4 w-4" />
          <span className="font-medium">💰 Earn Rewards for Pinging!</span>
        </div>
        <p className="text-green-700 text-xs mt-1">
          Earn {PING_REWARD} ETH for each ping you perform. Help monitor the network and get rewarded!
        </p>
      </div>

      {/* Wallet Status Display */}
      <div
        className={`space-y-2 p-3 border rounded-lg ${
          linkedWallet ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
        }`}
      >
        <div className="flex items-center gap-2">
          <Wallet className={`h-4 w-4 ${linkedWallet ? "text-green-600" : "text-red-600"}`} />
          <span className={`text-sm font-medium ${linkedWallet ? "text-green-800" : "text-red-800"}`}>
            {linkedWallet ? "Wallet Linked" : "Wallet Required"}
          </span>
        </div>

        {linkedWallet ? (
          <div className="text-xs text-green-600 space-y-1">
            <div className="font-mono bg-green-100 p-2 rounded">
              {linkedWallet.address.slice(0, 10)}...{linkedWallet.address.slice(-8)}
            </div>
            <p className="text-green-700">✅ Ready to earn rewards from pings</p>
          </div>
        ) : (
          <div className="text-xs text-red-700 space-y-2">
            <p>❌ Link your wallet to start earning rewards</p>
            <Button
              variant="outline"
              size="sm"
              onClick={handleNavigateToWallet}
              className="text-red-600 border-red-300 hover:bg-red-50 bg-transparent"
            >
              <Link className="h-3 w-3 mr-1" />
              Link Wallet
            </Button>
          </div>
        )}
      </div>

      {/* Simulate Button - Updated styling for earning */}
      <Button
        onClick={handleSimulatePing}
        disabled={!linkedWallet || isLoading}
        className="w-full bg-green-500 hover:bg-green-600 text-white disabled:bg-gray-400"
      >
        {isLoading ? (
          <div className="flex items-center gap-2">
            <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
            <span>Processing Ping...</span>
          </div>
        ) : linkedWallet ? (
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            <span>Ping & Earn {PING_REWARD} ETH</span>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Wallet className="h-4 w-4" />
            <span>Link Wallet to Ping</span>
          </div>
        )}
      </Button>

      {/* Last Result Display */}
      {lastResult && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-3">
          <div className="flex items-center gap-2 text-green-800 text-sm font-medium mb-2">
            <Coins className="h-4 w-4" />
            <span>Last Ping Result - Reward Earned!</span>
          </div>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Status:</span>
              <Badge variant={lastResult.result?.is_up ? "default" : "destructive"}>
                {lastResult.result?.is_up ? "UP" : "DOWN"}
              </Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Latency:</span>
              <span className="font-mono">{lastResult.result?.latency_ms || "N/A"}ms</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Region:</span>
              <span className="font-mono">{lastResult.result?.region || "unknown"}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Wallet Used:</span>
              <span className="font-mono text-xs">
                {linkedWallet?.address.slice(0, 6)}...{linkedWallet?.address.slice(-4)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Reward Earned:</span>
              <span className="font-mono text-xs text-green-600 font-semibold">+{PING_REWARD} ETH</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
