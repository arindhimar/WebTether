"use client"

import { motion } from "framer-motion"
import { Card, CardDescription, CardHeader, CardTitle } from "../ui/card"
import { Wallet, Globe, TrendingUp, Users } from "lucide-react"

export function HowItWorksSection() {
  const steps = [
    {
      title: "Pay to List Your Website",
      description: "Pay a one-time fee of 0.001 ETH to add your website to our decentralized monitoring network.",
      icon: Wallet,
      color: "from-primary to-blue-600",
    },
    {
      title: "Validators Monitor Your Site",
      description: "Our network of validators regularly ping your website to check uptime and performance.",
      icon: Users,
      color: "from-blue-600 to-indigo-600",
    },
    {
      title: "Earn ETH from Each Ping",
      description: "Receive 0.0001 ETH for every successful ping. The more active your site, the more you earn.",
      icon: TrendingUp,
      color: "from-green-500 to-emerald-600",
    },
    {
      title: "Track Performance & Earnings",
      description: "Monitor your website's uptime statistics and accumulated earnings in real-time.",
      icon: Globe,
      color: "from-purple-500 to-violet-600",
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { type: "spring", stiffness: 100 },
    },
  }

  return (
    <section id="how-it-works" className="w-full py-12 md:py-24 lg:py-32 bg-muted/30">
      <div className="container px-4 md:px-6">
        <motion.div
          className="flex flex-col items-center justify-center space-y-4 text-center"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.div className="space-y-2" variants={itemVariants}>
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              <span className="gradient-text">How WebTether Works</span>
            </h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              A revolutionary model where website owners earn rewards for participating in decentralized monitoring
            </p>
          </motion.div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 pt-8 w-full max-w-7xl">
            {steps.map((step, index) => (
              <motion.div key={index} className="relative" variants={itemVariants}>
                <Card className="h-full glass-card hover:border-primary/50 transition-all duration-300 group">
                  <CardHeader className="text-center p-6">
                    <div
                      className={`mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br ${step.color} group-hover:scale-110 transition-transform duration-300`}
                    >
                      <step.icon className="h-8 w-8 text-white" />
                    </div>
                    <div className="text-sm font-medium text-primary mb-2">Step {index + 1}</div>
                    <CardTitle className="text-lg mb-3">{step.title}</CardTitle>
                    <CardDescription className="text-sm leading-relaxed">{step.description}</CardDescription>
                  </CardHeader>
                </Card>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 -right-3 w-6 h-0.5 bg-gradient-to-r from-primary/50 to-primary/20" />
                )}
              </motion.div>
            ))}
          </div>

          <motion.div variants={itemVariants} className="mt-12 p-8 glass-card rounded-2xl max-w-4xl">
            <h3 className="text-2xl font-bold mb-4 gradient-text">Example Earnings</h3>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-3xl font-bold text-primary mb-2">0.001 ETH</div>
                <div className="text-sm text-muted-foreground">Initial listing cost</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-500 mb-2">+0.01 ETH</div>
                <div className="text-sm text-muted-foreground">After 100 pings</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-600 mb-2">+0.1 ETH</div>
                <div className="text-sm text-muted-foreground">After 1000 pings</div>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-4">
              The more reliable your website, the more validators will ping it, increasing your earnings potential.
            </p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
