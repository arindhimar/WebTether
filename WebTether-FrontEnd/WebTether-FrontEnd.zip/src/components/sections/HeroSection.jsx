"use client"

import { motion } from "framer-motion"
import { Button } from "../ui/button"
import { Badge } from "../ui/badge"
import { ArrowRight, Wallet, TrendingUp, Shield } from "lucide-react"
import { AnimatedCounter } from "../interactive/AnimatedCounter"
import { FloatingParticles } from "../interactive/FloatingParticles"

export function HeroSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { type: "spring", stiffness: 100 },
    },
  }

  return (
    <section id="home" className="w-full py-12 md:py-24 lg:py-32 xl:py-48 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-background via-primary/5 to-background/95" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/20 via-background/0 to-background/0" />
      <FloatingParticles />

      <div className="container px-4 md:px-6 relative z-10">
        <motion.div
          className="flex flex-col items-center space-y-4 text-center"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={itemVariants}>
            <Badge variant="outline" className="mb-4 border-primary/20 text-primary">
              <Wallet className="w-3 h-3 mr-1" />
              Earn While You Monitor
            </Badge>
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
              <span className="gradient-text">WebTether</span>
              <br />
              <span className="text-foreground">Decentralized Website Monitoring</span>
            </h1>
          </motion.div>

          <motion.div variants={itemVariants}>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Add your websites to our monitoring network and earn rewards for every ping. Pay once to list your site,
              then earn ETH as validators check your uptime. The more your site gets pinged, the more you earn.
            </p>
          </motion.div>

          <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-3 gap-6 py-8 w-full max-w-4xl">
            <div className="glass-card p-6 rounded-xl text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                <Wallet className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Pay to List</h3>
              <p className="text-sm text-muted-foreground">
                One-time payment of 0.001 ETH to add your website to our monitoring network
              </p>
            </div>
            <div className="glass-card p-6 rounded-xl text-center">
              <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                <TrendingUp className="w-6 h-6 text-green-500" />
              </div>
              <h3 className="font-semibold mb-2">Earn from Pings</h3>
              <p className="text-sm text-muted-foreground">
                Earn 0.0001 ETH every time a validator checks your website's uptime
              </p>
            </div>
            <div className="glass-card p-6 rounded-xl text-center">
              <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                <Shield className="w-6 h-6 text-blue-500" />
              </div>
              <h3 className="font-semibold mb-2">Reliable Monitoring</h3>
              <p className="text-sm text-muted-foreground">
                Decentralized network ensures accurate uptime tracking and fair rewards
              </p>
            </div>
          </motion.div>

          {/* Interactive Stats */}
          <motion.div variants={itemVariants} className="grid grid-cols-3 gap-8 py-4">
            <div className="text-center">
              <AnimatedCounter end={1247} duration={2000} />
              <p className="text-sm text-muted-foreground mt-1">Active Validators</p>
            </div>
            <div className="text-center">
              <AnimatedCounter end={15420} duration={2000} />
              <p className="text-sm text-muted-foreground mt-1">Websites Listed</p>
            </div>
            <div className="text-center">
              <AnimatedCounter end={2.4} duration={2000} suffix=" ETH" />
              <p className="text-sm text-muted-foreground mt-1">Total Earned</p>
            </div>
          </motion.div>

          <motion.div className="flex flex-col gap-2 min-[400px]:flex-row pt-4" variants={itemVariants}>
            <Button size="lg" className="bg-primary hover:bg-primary/90 group">
              Start Earning Today
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button variant="outline" size="lg" className="group bg-transparent">
              <TrendingUp className="mr-2 h-4 w-4 group-hover:scale-110 transition-transform" />
              View Live Stats
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
