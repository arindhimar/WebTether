"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Wallet, RefreshCw, TrendingUp, TrendingDown, History, Coins } from "lucide-react"
import { api } from "../services/api"

export function WalletBalance() {
  const [balance, setBalance] = useState(null)
  const [transactions, setTransactions] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [showTransactions, setShowTransactions] = useState(false)

  const fetchWalletData = async (showRefreshToast = false) => {
    try {
      setIsRefreshing(true)

      const [balanceData, transactionData] = await Promise.all([api.getWalletBalance(), api.getTransactionHistory()])

      setBalance(balanceData)
      setTransactions(transactionData.transactions || [])

      if (showRefreshToast) {
        console.log("Wallet data refreshed")
      }
    } catch (error) {
      console.error("Failed to fetch wallet data:", error)
    } finally {
      setIsRefreshing(false)
    }
  }

  useEffect(() => {
    fetchWalletData().finally(() => setIsLoading(false))
  }, [])

  // Calculate earnings vs spending for new economic model
  const calculateEarningsVsSpending = () => {
    if (!transactions.length) return { totalEarnings: 0, totalSpending: 0, netEarnings: 0 }

    let totalEarnings = 0
    let totalSpending = 0

    transactions.forEach((tx) => {
      const amount = Number.parseFloat(tx.amount || 0)
      if (tx.type === "ping_payment") {
        totalEarnings += amount // Pings now earn money
      } else if (tx.type === "website_creation") {
        totalSpending += amount // Website creation costs money
      }
    })

    return {
      totalEarnings,
      totalSpending,
      netEarnings: totalEarnings - totalSpending,
    }
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-6 w-6 border-2 border-blue-600 border-t-transparent" />
        </CardContent>
      </Card>
    )
  }

  if (!balance) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <Wallet className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-600">Failed to load wallet data</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  const { totalEarnings, totalSpending, netEarnings } = calculateEarningsVsSpending()

  return (
    <div className="space-y-4">
      {/* Main Balance Card */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Wallet className="h-5 w-5 text-blue-600" />
              Earnings Wallet
            </CardTitle>
            <Button variant="outline" size="sm" onClick={() => fetchWalletData(true)} disabled={isRefreshing}>
              <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
            </Button>
          </div>
          <CardDescription>Earn rewards by pinging websites on our network</CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* New Economic Model Notice */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <div className="flex items-center gap-2 text-blue-800 text-sm">
              <Coins className="h-4 w-4" />
              <span className="font-medium">💰 New Economic Model</span>
            </div>
            <p className="text-blue-700 text-xs mt-1">
              Pay to add websites • Earn rewards for pinging • Help monitor the network!
            </p>
          </div>

          {/* Balance Display */}
          <div className="space-y-3">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-900">{balance.eth_balance} ETH</div>
              <div className="text-sm text-gray-600">≈ ${balance.usd_value} USD</div>
            </div>

            {/* Wallet Address */}
            <div className="space-y-1">
              <label className="text-xs font-medium text-gray-600">Wallet Address</label>
              <div className="font-mono text-xs bg-gray-100 p-2 rounded border break-all">{balance.wallet_address}</div>
            </div>

            {/* Updated Stats Grid - Earnings vs Spending */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-center">
                <div className="flex items-center justify-center gap-1 text-green-600 mb-1">
                  <TrendingUp className="h-3 w-3" />
                  <span className="text-xs font-medium">Total Earned</span>
                </div>
                <div className="font-bold text-sm text-green-800">+{totalEarnings.toFixed(6)} ETH</div>
                <div className="text-xs text-green-600">From {balance.total_pings} pings</div>
              </div>

              <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-center">
                <div className="flex items-center justify-center gap-1 text-red-600 mb-1">
                  <TrendingDown className="h-3 w-3" />
                  <span className="text-xs font-medium">Total Spent</span>
                </div>
                <div className="font-bold text-sm text-red-800">-{totalSpending.toFixed(6)} ETH</div>
                <div className="text-xs text-red-600">Website creation</div>
              </div>
            </div>

            {/* Net Earnings Display */}
            <div
              className={`p-3 rounded-lg text-center ${netEarnings >= 0 ? "bg-green-50 border border-green-200" : "bg-red-50 border border-red-200"}`}
            >
              <div
                className={`flex items-center justify-center gap-1 mb-1 ${netEarnings >= 0 ? "text-green-600" : "text-red-600"}`}
              >
                <Coins className="h-4 w-4" />
                <span className="text-sm font-medium">Net Earnings</span>
              </div>
              <div className={`font-bold text-lg ${netEarnings >= 0 ? "text-green-800" : "text-red-800"}`}>
                {netEarnings >= 0 ? "+" : ""}
                {netEarnings.toFixed(6)} ETH
              </div>
              <div className={`text-xs ${netEarnings >= 0 ? "text-green-600" : "text-red-600"}`}>
                {netEarnings >= 0 ? "You're profitable!" : "Keep pinging to earn more!"}
              </div>
            </div>

            {/* Transaction History Toggle */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowTransactions(!showTransactions)}
              className="w-full"
            >
              <History className="h-4 w-4 mr-2" />
              {showTransactions ? "Hide" : "Show"} Transaction History
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Transaction History */}
      {showTransactions && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Transaction History</CardTitle>
            <CardDescription>Your earnings and spending on the network</CardDescription>
          </CardHeader>

          <CardContent>
            {transactions.length === 0 ? (
              <div className="text-center py-6">
                <History className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-600 text-sm">No transactions yet</p>
                <p className="text-gray-500 text-xs">Start pinging websites to earn your first rewards!</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {transactions.map((tx, index) => {
                  const isEarning = tx.type === "ping_payment"
                  return (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {tx.tx_hash}
                          </Badge>
                          <Badge
                            variant={isEarning ? "default" : "secondary"}
                            className={`text-xs ${isEarning ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}
                          >
                            {isEarning ? "EARNED" : "SPENT"}
                          </Badge>
                        </div>
                        <div className="text-xs text-gray-600 mt-1">{new Date(tx.timestamp).toLocaleString()}</div>
                      </div>
                      <div className="text-right">
                        <div className={`font-mono text-sm ${isEarning ? "text-green-600" : "text-red-600"}`}>
                          {isEarning ? "+" : "-"}
                          {tx.amount} ETH
                        </div>
                        <div className="text-xs text-gray-500">{isEarning ? "Ping reward" : "Website creation"}</div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
