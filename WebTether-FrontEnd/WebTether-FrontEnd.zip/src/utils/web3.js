import { ethers } from 'ethers'

// Local Hardhat configuration
export const LOCAL_RPC_URL = "http://localhost:8545"
export const PING_CONTRACT_ADDRESS = "0x5FbDB2315678afecb367f032d93F642f64180aa3" // Default Hardhat deployment address

// Simple contract ABI for recordPing function
export const PING_CONTRACT_ABI = [
  "function recordPing(uint256 wid, uint256 uid, uint256 amount) returns (bool)",
  "function getPingCount() view returns (uint256)",
  "function owner() view returns (address)"
]

export class LocalWeb3Service {
  constructor() {
    this.provider = null
    this.signer = null
    this.contract = null
    this.isLocal = true
  }

  async connectToLocal() {
    try {
      // Connect to local Hardhat node
      this.provider = new ethers.JsonRpcProvider(LOCAL_RPC_URL)
      
      // Test connection
      const network = await this.provider.getNetwork()
      console.log("Connected to local network:", network.chainId.toString())
      
      // Try to connect MetaMask first, fallback to Hardhat account
      if (window.ethereum) {
        try {
          await window.ethereum.request({ method: 'eth_requestAccounts' })
          const browserProvider = new ethers.BrowserProvider(window.ethereum)
          this.signer = await browserProvider.getSigner()
          console.log("Using MetaMask signer")
        } catch (error) {
          console.log("MetaMask not available, using Hardhat account")
          this.signer = await this.provider.getSigner(0) // Use first Hardhat account
        }
      } else {
        // Use Hardhat test account
        this.signer = await this.provider.getSigner(0)
        console.log("Using Hardhat test account")
      }

      // Initialize contract
      this.contract = new ethers.Contract(
        PING_CONTRACT_ADDRESS,
        PING_CONTRACT_ABI,
        this.signer
      )

      const address = await this.signer.getAddress()
      console.log("Connected with address:", address)
      
      return address
    } catch (error) {
      console.error("Failed to connect to local blockchain:", error)
      throw new Error("Failed to connect to local Hardhat node. Make sure it's running on http://localhost:8545")
    }
  }

  async getBalance(address) {
    if (!this.provider) {
      throw new Error("Provider not initialized")
    }

    try {
      const balance = await this.provider.getBalance(address)
      return ethers.formatEther(balance)
    } catch (error) {
      console.error("Failed to get balance:", error)
      throw new Error("Failed to fetch balance")
    }
  }

  async recordPing(wid, uid, amount = "0.001") {
    if (!this.contract || !this.signer) {
      throw new Error("Contract not initialized")
    }

    try {
      console.log(`Recording ping: wid=${wid}, uid=${uid}, amount=${amount} ETH`)
      
      // Convert amount to wei
      const amountInWei = ethers.parseEther(amount.toString())
      
      // Call contract function
      const tx = await this.contract.recordPing(wid, uid, amountInWei, {
        value: amountInWei, // Send ETH with transaction
        gasLimit: 100000 // Set reasonable gas limit
      })

      console.log("Transaction sent:", tx.hash)
      
      // Wait for confirmation
      const receipt = await tx.wait()
      console.log("Transaction confirmed:", receipt)
      
      return {
        hash: tx.hash,
        receipt: receipt,
        amountPaid: amount
      }
    } catch (error) {
      console.error("Contract call failed:", error)
      
      // Handle specific error cases
      if (error.code === 'INSUFFICIENT_FUNDS') {
        throw new Error("Insufficient ETH balance for this transaction")
      } else if (error.code === 'USER_REJECTED') {
        throw new Error("Transaction was rejected by user")
      }
      
      throw new Error(`Contract call failed: ${error.message}`)
    }
  }

  async getPingCount() {
    if (!this.contract) {
      throw new Error("Contract not initialized")
    }

    try {
      const count = await this.contract.getPingCount()
      return count.toString()
    } catch (error) {
      console.error("Failed to get ping count:", error)
      return "0"
    }
  }

  // Helper to check if local node is running
  async isLocalNodeRunning() {
    try {
      const provider = new ethers.JsonRpcProvider(LOCAL_RPC_URL)
      await provider.getNetwork()
      return true
    } catch (error) {
      return false
    }
  }
}

export const localWeb3Service = new LocalWeb3Service()
